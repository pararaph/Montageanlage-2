D   Ihre CAD Daten vom 02.01.2023 von Festo:

    Sehr geehrte Kundin, sehr geehrter Kunde,
    
    im Anhang finden Sie folgende Datei unseres 2D/3D-CAD Portals powered by CADENAS:
    
	Identifikationsnummer: 8112003 DSNU-S-12-6-P-A 
    
    STEP, 8112003 DSNU-S-12-6-P-A---(0), 8112003_DSNU-S-12-6-P-A.stp
    
    Bitte beachten Sie auch die Download Vereinbarung unter:
    https://www.cadenas.de/nutzungsbedingungen-3d-cad-modelle
    
    Mit freundlichen Gr��en
    
    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
    