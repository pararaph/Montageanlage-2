D   Ihre CAD Daten vom 07.03.2023 von Festo:

    Sehr geehrte Kundin, sehr geehrter Kunde,
    
    im Anhang finden Sie folgende Datei unseres 2D/3D-CAD Portals powered by CADENAS:
    
	Identifikationsnummer: 4149945 DFM-6-10-P-A-GF 
    
    STEP, 4149945 DFM-6-10-P-A-GF---(0), 4149945_DFM-6-10-P-A-GF.stp
    
    Bitte beachten Sie auch die Download Vereinbarung unter:
    https://www.cadenas.de/nutzungsbedingungen-3d-cad-modelle
    
    Mit freundlichen Gr��en
    
    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
    