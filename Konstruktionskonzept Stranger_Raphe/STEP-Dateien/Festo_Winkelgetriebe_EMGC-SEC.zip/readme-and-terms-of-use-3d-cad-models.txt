D   Ihre CAD Daten vom 18.12.2022 von Festo:

    Sehr geehrte Kundin, sehr geehrter Kunde,
    
    im Anhang finden Sie folgende Datei unseres 2D/3D-CAD Portals powered by CADENAS:
    
	Identifikationsnummer: 2321480 EMGC-67-A-G1-SEC-67 
    
    STEP, 2321480 EMGC-67-A-G1-SEC-67, 2321480_EMGC-67-A-G1-SEC-67.stp
    
    Bitte beachten Sie auch die Download Vereinbarung unter:
    https://www.cadenas.de/nutzungsbedingungen-3d-cad-modelle
    
    Mit freundlichen Gr��en
    
    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
    