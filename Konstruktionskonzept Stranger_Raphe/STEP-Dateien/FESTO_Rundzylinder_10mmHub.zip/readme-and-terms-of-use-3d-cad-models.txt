D   Ihre CAD Daten vom 09.12.2022 von Festo:

    Sehr geehrte Kundin, sehr geehrter Kunde,
    
    im Anhang finden Sie folgende Datei unseres 2D/3D-CAD Portals powered by CADENAS:
    
	Identifikationsnummer: 5211896 DSNU-S-12-10-P-A 
    
    STEP, 5211896 DSNU-S-12-10-P-A-MQ---(0), 5211896_DSNU-S-12-10-P-A.stp
    
    Bitte beachten Sie auch die Download Vereinbarung unter:
    https://www.cadenas.de/nutzungsbedingungen-3d-cad-modelle
    
    Mit freundlichen Gr��en
    
    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
    