D   Ihre CAD Daten vom 12.10.2022 von Festo:

    Sehr geehrte Kundin, sehr geehrter Kunde,
    
    im Anhang finden Sie folgende Datei unseres 2D/3D-CAD Portals powered by CADENAS:
    
	Identifikationsnummer: 186096 QS-G1/8-6 
    
    STEP, 186096 QS-G1/8-6, 186096_QS-G1_8-6.stp
    
    Bitte beachten Sie auch die Download Vereinbarung unter:
    https://www.cadenas.de/nutzungsbedingungen-3d-cad-modelle
    
    Mit freundlichen Gr��en
    
    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
    