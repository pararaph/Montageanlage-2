D   Ihre CAD Daten vom 21.03.2023 von Festo:

    Sehr geehrte Kundin, sehr geehrter Kunde,
    
    im Anhang finden Sie folgende Datei unseres 2D/3D-CAD Portals powered by CADENAS:
    
	Identifikationsnummer: 8092120 ADN-S-63-20-A-P-A 
    
    STEP, 8092120 ADN-S-63-20-A-P-A---(0_high), 8092120_ADN-S-63-20-A-P-A.stp
    
    Bitte beachten Sie auch die Download Vereinbarung unter:
    https://www.cadenas.de/nutzungsbedingungen-3d-cad-modelle
    
    Mit freundlichen Gr��en
    
    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
    