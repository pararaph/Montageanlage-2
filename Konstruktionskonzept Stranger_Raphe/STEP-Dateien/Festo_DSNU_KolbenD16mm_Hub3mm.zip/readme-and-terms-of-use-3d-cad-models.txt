D   Ihre CAD Daten vom 02.01.2023 von Festo:

    Sehr geehrte Kundin, sehr geehrter Kunde,
    
    im Anhang finden Sie folgende Datei unseres 2D/3D-CAD Portals powered by CADENAS:
    
	Identifikationsnummer: 8112004 DSNU-S-16-3-P-A 
    
    STEP, 8112004 DSNU-S-16-3-P-A---(0), 8112004_DSNU-S-16-3-P-A.stp
    
    Bitte beachten Sie auch die Download Vereinbarung unter:
    https://www.cadenas.de/nutzungsbedingungen-3d-cad-modelle
    
    Mit freundlichen Gr��en
    
    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
    