D   Ihre CAD Daten vom 18.12.2022 von Festo:

    Sehr geehrte Kundin, sehr geehrter Kunde,
    
    im Anhang finden Sie folgende Datei unseres 2D/3D-CAD Portals powered by CADENAS:
    
	Identifikationsnummer: 8034238 EMCA-EC-67-S-1TE-CO 
    
    STEP, 8034238 EMCA-EC-67-S-1TE-CO, 8034238_EMCA-EC-67-S-1TE-CO.stp
    
    Bitte beachten Sie auch die Download Vereinbarung unter:
    https://www.cadenas.de/nutzungsbedingungen-3d-cad-modelle
    
    Mit freundlichen Gr��en
    
    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
    